// Computing lab II (CS69012 )  ||   Assignment #1  
//Submitted by - Ravi Pratap Singh (20CS60R60 )

(on linux kernal)
Compilation command for server :  gcc server.c -o server -lm
Running command for server :   ./server

Compilation command for client :  gcc client.c -o client 
Running command for client :   ./client

**NOTE : 1.The server has to run first and then the client
               

