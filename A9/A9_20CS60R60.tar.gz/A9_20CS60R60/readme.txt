// Computing lab II ||  CS69012  ||   Assignment #9
//Submitted by - Ravi Pratap Singh (20CS60R60)

Note : Although  "task2.py"  contains all functionality for both task1 and taks2 . Still both
      tasks can be executed independently .

Task1 :
    command to run : ~$ python3 task1.py
--->All the pre downloaded movie pages should be present in ./MOVIE directory<--- (code for that present in A8-task1)
    Instructions to user:
    1.Along with the information asked in A8-task2 it includes additional functionality of
        a.You might also like (option no. 9)
        b.Where To watch      (option no. 10)
    2. Asks user to choose a movie according to the index (1-N)
    3. According to movie choice it presents 10 options to choose from ,user should enter values from 1-N .
    4. The option for *you might also like* and *where to watch* are present at index 9 and 10 respectively .
    5. After any option from 1-10 except option 9 ,information are displayed on the console.
    6. For information which have multiple entries , it get displayed in separate lines.
    7. For option 9:
        a. The suggested movie names are shown.
        b. Then user is asked for 10 options to choose from.
        c. For option 9 , goes to step 7.
        d. For other option , the corresponding field's detail is shown and move to step 8.
    8. After choosing any one of the option from 1-10 , user get choice to continue on original movie list .
    9. If selects *yes* then steps 2 - 9 are repeated if *no* then exits .

Task2 :
    command to run : ~$ python3 task2.py

    Instructions  to  user:
    1.Along with the information asked in A8-task2 and A9-task1 ,this task expands functionality of option 5
      i.e *cast and crew*
    2. All the instruction from task1 are still valid except for option no.5 for which new options are added.
    3. For option no. 5:
        a.Asks user to choose from the cast list in format of indices i.e 1-N.
------->b.According to that it downloads the webpage for that cast and saves in "./CAST_PROFILE" directory.<-------
        c.Then does the lexing and parsing on new web-page.
        d.It then asks user to enter option from 1-4 .
        e.For option 1-3 , the data is directly shown.
        f.For option 4 , asks for year to filter and then displays the output.
        g.Then Prompts for *yes* or *no* to get more info on the cast.
        f.If *yes* is choosen then steps d-g are repeated .
        h.If *no* is choosen then it goes back to choosing yes/no option for original movie list