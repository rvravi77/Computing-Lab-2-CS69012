// Computing lab II ||  CS69012  ||   Assignment #6
//Submitted by - Ravi Pratap Singh (20CS60R60 )

Running command for all queries in Query_<no.> directory : (on linux kernal) 
~$ make run

Note:
1.Assumed "network.txt" in the same directory as of makefile,mapper.py,reducer.py.
2."result.txt" generated in same directory for all queries.
3.query3 uses "result.txt" from query2 and accessed as "../Query2/result.txt".
4.query3 excludes link(edge) in between top10 users.