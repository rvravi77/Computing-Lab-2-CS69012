// Computing lab II ||  CS69012  ||   Assignment #10
//Submitted by - Ravi Pratap Singh (20CS60R60)

For RNN : training commnad : ~$python3 rnn.py --train 
          testing commnad :  ~$python3 rnn.py --test

For CNN : training commnad : ~$python3 cnn.py --train 
          testing commnad :  ~$python3 cnn.py --test

Note : 
       1. If code creates some issue on running on linux kernel, please try it on google
	  colab , link for that present in report as well as at the top of the code . 
       2. More details about model parameters and inferences are mentioned in the report . 
       3. CNN model weights were difficult to compress into Moodle file size limit so they are 
	  present in this shared drive folder : 
	  https://drive.google.com/drive/folders/1KNl1hib4F7zKx97AbcP8wXX40129Jm79?usp=sharing
	 *** download the folder log_cnn and keep in current directory as of cnn.py
	 